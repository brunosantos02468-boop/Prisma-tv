/* Prisma TV - Samsung Smart TV (Orsay, 2013-2015). Somente ES5. */

var VERSION = '1.1';
var widgetAPI = null;

function $(id) { return document.getElementById(id); }
function esc(s) {
	return String(s === null || s === undefined ? '' : s)
		.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function cut(s, n) { s = String(s || ''); return s.length > n ? s.substr(0, n - 1) + '\u2026' : s; }
function pad2(n) { return n < 10 ? '0' + n : '' + n; }
function fmtTime(ms) {
	var s = Math.floor((ms || 0) / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
	s = s % 60;
	return (h > 0 ? h + ':' + pad2(m) : m) + ':' + pad2(s);
}

/* ---------- registro de erros (tecla AZUL mostra) ---------- */
var Log = {
	lines: [], shown: false,
	add: function (m) {
		this.lines.push(String(m));
		if (this.lines.length > 28) { this.lines.shift(); }
		if (this.shown) { this.draw(); }
	},
	draw: function () { $('log').innerHTML = esc(this.lines.join('\n')).replace(/\n/g, '<br>'); },
	toggle: function () {
		this.shown = !this.shown;
		$('log').style.display = this.shown ? 'block' : 'none';
		if (this.shown) { this.draw(); }
	}
};
window.onerror = function (m, u, l) { Log.add('ERRO: ' + m + ' (linha ' + l + ')'); return false; };

/* ---------- armazenamento (se a TV nao guardar, usa a memoria) ---------- */
var Store = {
	mem: {},
	get: function (k, def) {
		try {
			var v = window.localStorage.getItem('prisma_' + k);
			if (v !== null && v !== undefined) { return JSON.parse(v); }
		} catch (e) {}
		return this.mem[k] !== undefined ? this.mem[k] : def;
	},
	set: function (k, v) {
		this.mem[k] = v;
		try { window.localStorage.setItem('prisma_' + k, JSON.stringify(v)); } catch (e) {}
	},
	del: function (k) {
		delete this.mem[k];
		try { window.localStorage.removeItem('prisma_' + k); } catch (e) {}
	}
};

var Prefs = {
	data: { liveFmt: 'm3u8', hideAdult: true },
	load: function () {
		var d = Store.get('prefs', null);
		if (d) { this.data.liveFmt = d.liveFmt || 'm3u8'; this.data.hideAdult = d.hideAdult !== false; }
	},
	save: function () { Store.set('prefs', this.data); }
};

function itemKey(it) { return it.k + ':' + it.id; }
function slim(it) {
	return { k: it.k, id: it.id, name: it.name, img: it.img || '', ext: it.ext || '', rating: it.rating || '' };
}

var Favs = {
	list: [],
	load: function () { this.list = Store.get('favs', []); },
	has: function (it) {
		var k = itemKey(it);
		for (var i = 0; i < this.list.length; i++) { if (itemKey(this.list[i]) === k) { return true; } }
		return false;
	},
	toggle: function (it) {
		var k = itemKey(it), out = [], found = false;
		for (var i = 0; i < this.list.length; i++) {
			if (itemKey(this.list[i]) === k) { found = true; } else { out.push(this.list[i]); }
		}
		if (!found) { out.unshift(slim(it)); }
		this.list = out;
		Store.set('favs', this.list);
	}
};

var Recent = {
	list: [],
	load: function () { this.list = Store.get('recent', []); },
	find: function (it) {
		var k = itemKey(it);
		for (var i = 0; i < this.list.length; i++) { if (itemKey(this.list[i]) === k) { return this.list[i]; } }
		return null;
	},
	put: function (it, url, title, pos, dur) {
		var k = itemKey(it), out = [];
		for (var i = 0; i < this.list.length; i++) { if (itemKey(this.list[i]) !== k) { out.push(this.list[i]); } }
		if (pos < dur * 0.95) {
			var r = slim(it); r.url = url; r.title = title; r.pos = pos; r.dur = dur;
			out.unshift(r);
		}
		while (out.length > 20) { out.pop(); }
		this.list = out;
		Store.set('recent', this.list);
	}
};

var ADULT = /adult|xxx|porn|nsfw|er[o\u00f3]tic|\+ ?18|18 ?\+|sexo|hentai|playboy|brazzers/i;
var AdultCats = { live: {}, movie: {}, series: {} };
function isAdultItem(kind, it) {
	return ADULT.test(it.name) || !!(it.cat && AdultCats[kind] && AdultCats[kind][it.cat]);
}

/* ---------- API Xtream Codes ---------- */
var Api = {
	base: '', user: '', pass: '',
	set: function (c) { this.base = c.server; this.user = c.user; this.pass = c.pass; },
	url: function (action, extra) {
		var u = this.base + '/player_api.php?username=' + encodeURIComponent(this.user) +
			'&password=' + encodeURIComponent(this.pass);
		if (action) { u += '&action=' + action; }
		if (extra) { u += extra; }
		return u;
	},
	get: function (action, extra, ok, fail) {
		var x = new XMLHttpRequest(), done = false;
		var to = setTimeout(function () {
			if (!done) { done = true; try { x.abort(); } catch (e) {} fail('Tempo esgotado'); }
		}, 90000);
		x.onreadystatechange = function () {
			if (x.readyState !== 4 || done) { return; }
			done = true; clearTimeout(to);
			if (x.status >= 200 && x.status < 300) {
				var d;
				try { d = JSON.parse(x.responseText); } catch (e) { fail('Resposta invalida do servidor'); return; }
				ok(d);
			} else if (x.status === 0) { fail('Sem conexao com o servidor'); }
			else { fail('Servidor respondeu ' + x.status); }
		};
		try {
			x.open('GET', this.url(action, extra), true);
			x.send(null);
		} catch (e) { done = true; clearTimeout(to); fail('Erro de rede'); }
	},
	login: function (ok, fail) {
		this.get(null, null, function (d) {
			var u = d && d.user_info;
			if (!u || String(u.auth) !== '1') { fail('Usuario ou senha incorretos'); return; }
			if (String(u.status).toLowerCase() === 'expired') { fail('Assinatura expirada'); return; }
			ok();
		}, fail);
	},
	cats: function (kind, ok, fail) {
		var a = kind === 'live' ? 'get_live_categories' : (kind === 'movie' ? 'get_vod_categories' : 'get_series_categories');
		this.get(a, null, function (d) {
			var out = [];
			if (d && d.length) {
				for (var i = 0; i < d.length; i++) {
					var cid = String(d[i].category_id), cnm = String(d[i].category_name);
					if (ADULT.test(cnm)) { AdultCats[kind][cid] = true; }
					out.push({ id: cid, name: cnm });
				}
			}
			ok(out);
		}, fail);
	},
	items: function (kind, catId, ok, fail) {
		var a = kind === 'live' ? 'get_live_streams' : (kind === 'movie' ? 'get_vod_streams' : 'get_series');
		this.get(a, catId ? '&category_id=' + catId : '', function (d) {
			var out = [];
			if (d && d.length) {
				for (var i = 0; i < d.length; i++) {
					var o = d[i];
					if (kind === 'series') {
						out.push({ k: 'series', id: String(o.series_id), name: String(o.name), img: o.cover || '', rating: o.rating || '', cat: String(o.category_id || '') });
					} else if (kind === 'movie') {
						out.push({ k: 'movie', id: String(o.stream_id), name: String(o.name), img: o.stream_icon || '',
							ext: o.container_extension || 'mp4', rating: o.rating || '', cat: String(o.category_id || '') });
					} else {
						out.push({ k: 'live', id: String(o.stream_id), name: String(o.name), img: o.stream_icon || '', cat: String(o.category_id || '') });
					}
				}
			}
			ok(out);
		}, fail);
	},
	movieInfo: function (id, ok, fail) {
		this.get('get_vod_info', '&vod_id=' + id, function (d) { ok((d && d.info) || {}); }, fail);
	},
	seriesInfo: function (id, ok, fail) {
		this.get('get_series_info', '&series_id=' + id, function (d) {
			var eps = [], e = d && d.episodes;
			if (e) {
				for (var s in e) {
					if (!e.hasOwnProperty(s) || !e[s] || !e[s].length) { continue; }
					for (var i = 0; i < e[s].length; i++) {
						var o = e[s][i];
						eps.push({ id: String(o.id), season: parseInt(s, 10) || 0, num: parseInt(o.episode_num, 10) || (i + 1),
							title: String(o.title || ('Episodio ' + (i + 1))), ext: o.container_extension || 'mp4' });
					}
				}
			}
			eps.sort(function (a, b) { return a.season !== b.season ? a.season - b.season : a.num - b.num; });
			ok((d && d.info) || {}, eps);
		}, fail);
	},
	liveUrl: function (id) { return this.base + '/live/' + this.user + '/' + this.pass + '/' + id + '.' + Prefs.data.liveFmt; },
	movieUrl: function (id, ext) { return this.base + '/movie/' + this.user + '/' + this.pass + '/' + id + '.' + ext; },
	episodeUrl: function (id, ext) { return this.base + '/series/' + this.user + '/' + this.pass + '/' + id + '.' + ext; }
};

/* ---------- teclado na tela ---------- */
var KB_LOGIN = [
	['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
	['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
	['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ':'],
	['z', 'x', 'c', 'v', 'b', 'n', 'm', '.', '-', '_'],
	['/', '@', 'http://', 'Espa\u00e7o', 'Ma\u00fasc', 'Apagar', 'OK']
];
var KB_SEARCH = [
	['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
	['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
	['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', '\u00e7'],
	['z', 'x', 'c', 'v', 'b', 'n', 'm', '.', '-', ':'],
	['Canais', 'Filmes', 'S\u00e9ries', 'Espa\u00e7o', 'Apagar', 'Limpar']
];

function Osk(def) { this.def = def; this.r = 0; this.c = 0; this.shift = false; this.active = true; this.on = ''; }
Osk.prototype.label = function (r, c) {
	var t = this.def[r][c];
	return (this.shift && t.length === 1) ? t.toUpperCase() : t;
};
Osk.prototype.html = function () {
	var h = '';
	for (var r = 0; r < this.def.length; r++) {
		h += '<div class="krow">';
		for (var c = 0; c < this.def[r].length; c++) {
			var t = this.def[r][c], cls = 'key';
			if (this.active && r === this.r && c === this.c) { cls += ' sel'; }
			if ((t === 'Ma\u00fasc' && this.shift) || (this.on && t === this.on)) { cls += ' on'; }
			h += '<div class="' + cls + '">' + esc(this.label(r, c)) + '</div>';
		}
		h += '</div>';
	}
	return h;
};
Osk.prototype.move = function (a) {
	var d = this.def, moved = false;
	if (a === 'left' && this.c > 0) { this.c--; moved = true; }
	else if (a === 'right' && this.c < d[this.r].length - 1) { this.c++; moved = true; }
	else if (a === 'up' && this.r > 0) { this.r--; moved = true; }
	else if (a === 'down' && this.r < d.length - 1) { this.r++; moved = true; }
	if (this.c > d[this.r].length - 1) { this.c = d[this.r].length - 1; }
	return moved;
};
Osk.prototype.press = function () {
	var t = this.def[this.r][this.c];
	if (t === 'Ma\u00fasc') { this.shift = !this.shift; return null; }
	return this.label(this.r, this.c);
};

/* ---------- estado geral ---------- */
var TABS = [
	{ id: 'home', label: 'In\u00edcio' },
	{ id: 'live', label: 'Canais' },
	{ id: 'movie', label: 'Filmes' },
	{ id: 'series', label: 'S\u00e9ries' },
	{ id: 'search', label: 'Buscar' },
	{ id: 'settings', label: 'Ajustes' }
];
var SCREENS = ['login', 'browse', 'search', 'settings', 'detail', 'player'];
var S = { screen: 'login', prev: 'browse', tab: 0, zone: 'tabs', rows: [], row: 0, top: 0, loading: false, err: '' };
var Cats = {};
var All = {};

function showScreen(name) {
	S.screen = name;
	for (var i = 0; i < SCREENS.length; i++) {
		$('scr-' + SCREENS[i]).style.display = SCREENS[i] === name ? 'block' : 'none';
	}
	var withHdr = (name === 'browse' || name === 'search' || name === 'settings');
	$('hdr').style.display = withHdr ? 'block' : 'none';
	document.body.className = name === 'player' ? 'playing' : '';
	document.documentElement.className = name === 'player' ? 'playing' : '';
	setHint(name);
}
function setHint(name) {
	var h = '';
	if (name === 'browse') { h = 'OK: abrir    VERMELHO: adicionar/remover da Minha lista    AZUL: registro'; }
	else if (name === 'search') { h = 'OK: digitar    VERMELHO: Minha lista    RETURN: voltar'; }
	else if (name === 'detail') { h = 'OK: selecionar    VERMELHO: Minha lista    RETURN: voltar'; }
	else if (name === 'player') { h = ''; }
	$('hint').innerHTML = h;
}

function visFor(row) { return row.kind === 'live' ? 5 : 7; }
function cardHtml(it, sel) {
	var live = it.k === 'live';
	var h = '<div class="card' + (live ? ' live' : '') + (sel ? ' sel' : '') + '"><div class="pic">';
	h += '<div class="ph">' + esc(String(it.name).substr(0, 2)) + '</div>';
	if (it.img) { h += '<img src="' + esc(it.img) + '" onerror="this.style.display=\'none\'">'; }
	if (Favs.has(it)) { h += '<div class="heart">\u2665</div>'; }
	if (it.dur && it.pos) { h += '<div class="prog"><div style="width:' + Math.round(100 * it.pos / it.dur) + '%"></div></div>'; }
	h += '</div><div class="cap">' + esc(cut(it.name, live ? 22 : 15)) + '</div></div>';
	return h;
}
function cardsHtml(items, start, vis, col, active) {
	var h = '';
	for (var i = start; i < items.length && i < start + vis; i++) { h += cardHtml(items[i], active && i === col); }
	return h;
}

/* ---------- cabecalho e abas ---------- */
function drawHeader() {
	var h = '';
	for (var i = 0; i < TABS.length; i++) {
		var c = 'tab' + (i === S.tab ? ' cur' : '') + ((i === S.tab && S.zone === 'tabs') ? ' foc' : '');
		h += '<div class="' + c + '">' + TABS[i].label + '</div>';
	}
	$('tabs').innerHTML = h;
}
function exitApp() {
	Player.stop(true);
	try { if (widgetAPI) { widgetAPI.sendReturnEvent(); } } catch (e) {}
}
function applyTab() {
	var id = TABS[S.tab].id;
	if (id === 'search') { showScreen('search'); Search.enter(); }
	else if (id === 'settings') { showScreen('settings'); Settings.draw(); }
	else { showScreen('browse'); Browse.build(); }
	drawHeader();
}
function tabsKey(a) {
	if (a === 'left' && S.tab > 0) { S.tab--; applyTab(); }
	else if (a === 'right' && S.tab < TABS.length - 1) { S.tab++; applyTab(); }
	else if (a === 'down' || a === 'enter') {
		var id = TABS[S.tab].id;
		if (id === 'home' || id === 'live' || id === 'movie' || id === 'series') {
			if (S.rows.length) { S.zone = 'content'; Browse.draw(); }
		} else { S.zone = 'content'; if (id === 'search') { Search.draw(); } else { Settings.draw(); } }
		drawHeader();
	} else if (a === 'back') { exitApp(); }
}

/* ---------- navegacao em linhas de posters ---------- */
var Browse = {
	curKind: function () { return TABS[S.tab].id; },
	build: function () {
		var t = this.curKind();
		S.rows = []; S.row = 0; S.top = 0; S.err = '';
		if (t === 'home') {
			if (Recent.list.length) { S.rows.push({ title: 'Continuar assistindo', kind: 'movie', items: Recent.list.slice(0), col: 0, start: 0 }); }
			if (Favs.list.length) { S.rows.push({ title: 'Minha lista', kind: 'movie', items: Favs.list.slice(0), col: 0, start: 0 }); }
			this.draw();
			return;
		}
		if (Cats[t]) { S.rows = this.rowsFrom(t, Cats[t]); this.draw(); this.ensure(); return; }
		S.loading = true; this.draw();
		Api.cats(t, function (c) {
			Cats[t] = c; S.loading = false;
			if (Browse.curKind() === t && S.screen === 'browse') { S.rows = Browse.rowsFrom(t, c); Browse.draw(); Browse.ensure(); }
		}, function (e) {
			S.loading = false; S.err = e;
			if (Browse.curKind() === t && S.screen === 'browse') { Browse.draw(); }
		});
	},
	rowsFrom: function (t, cats) {
		var rows = [];
		for (var i = 0; i < cats.length; i++) {
			if (ADULT.test(cats[i].name)) { continue; }
			rows.push({ title: cats[i].name, kind: t, cat: cats[i].id, items: null, loading: false, col: 0, start: 0 });
		}
		return rows;
	},
	ensure: function () {
		for (var r = S.top; r < S.top + 3 && r < S.rows.length; r++) {
			var row = S.rows[r];
			if (row.items === null && !row.loading) { this.load(row); }
		}
	},
	load: function (row) {
		row.loading = true;
		Api.items(row.kind, row.cat, function (list) {
			row.items = list; row.loading = false;
			if (S.screen === 'browse') { Browse.draw(); }
		}, function (e) {
			row.items = []; row.err = e; row.loading = false;
			if (S.screen === 'browse') { Browse.draw(); }
		});
	},
	draw: function () {
		var h = '', msg = '';
		for (var r = S.top; r < S.rows.length && r < S.top + 2; r++) {
			var row = S.rows[r];
			h += '<div class="row"><div class="row-title">' + esc(cut(row.title, 60)) + '</div><div class="row-cards">';
			if (row.items === null) { h += '<div class="empty">Carregando\u2026</div>'; }
			else if (!row.items.length) { h += '<div class="empty">' + esc(row.err || 'Nada aqui') + '</div>'; }
			else { h += cardsHtml(row.items, row.start, visFor(row), row.col, S.zone === 'content' && r === S.row); }
			h += '</div></div>';
		}
		$('rows').innerHTML = h;
		if (S.loading) { msg = 'Carregando\u2026'; }
		else if (S.err) { msg = esc(S.err) + '<br>Confira seu acesso em Ajustes > Sair.'; }
		else if (!S.rows.length) {
			msg = this.curKind() === 'home' ? 'Nada por aqui ainda.<br>Aperte VERMELHO em um t\u00edtulo para guard\u00e1-lo na Minha lista.' : 'Nenhuma categoria encontrada.';
		}
		$('br-msg').innerHTML = msg;
	},
	fixTop: function () {
		if (S.row < S.top) { S.top = S.row; } else if (S.row > S.top + 1) { S.top = S.row - 1; }
	},
	fixCol: function (row) {
		var v = visFor(row);
		if (row.col < row.start) { row.start = row.col; } else if (row.col >= row.start + v) { row.start = row.col - v + 1; }
	},
	key: function (a) {
		if (S.zone === 'tabs') { tabsKey(a); return; }
		var row = S.rows[S.row];
		var it = row && row.items && row.items[row.col];
		if (a === 'up') { if (S.row > 0) { S.row--; this.fixTop(); } else { S.zone = 'tabs'; } }
		else if (a === 'down') { if (S.row < S.rows.length - 1) { S.row++; this.fixTop(); } }
		else if (a === 'left') { if (row && row.col > 0) { row.col--; this.fixCol(row); } }
		else if (a === 'right') { if (row && row.items && row.col < row.items.length - 1) { row.col++; this.fixCol(row); } }
		else if (a === 'enter') { if (it) { openItem(it); } return; }
		else if (a === 'red') { if (it) { Favs.toggle(it); if (this.curKind() === 'home') { this.refreshHome(); } } }
		else if (a === 'back') { S.zone = 'tabs'; }
		this.draw(); drawHeader(); this.ensure();
	},
	refreshHome: function () {
		var keep = S.row;
		this.build();
		if (keep >= S.rows.length) { keep = S.rows.length - 1; }
		if (keep < 0) { keep = 0; S.zone = 'tabs'; }
		S.row = keep; this.fixTop(); this.draw();
	}
};

/* ---------- busca ---------- */
var Search = {
	kind: 'movie', q: '', results: [], zone: 'k', col: 0, start: 0, osk: null, timer: null, loading: false, msg: '',
	enter: function () {
		if (!this.osk) { this.osk = new Osk(KB_SEARCH); }
		this.osk.on = this.kindLabel();
		this.draw();
	},
	kindLabel: function () { return this.kind === 'live' ? 'Canais' : (this.kind === 'movie' ? 'Filmes' : 'S\u00e9ries'); },
	draw: function () {
		this.osk.active = (S.zone === 'content' && this.zone === 'k');
		$('sr-query').innerHTML = esc(this.q) + '<span style="color:#e50914">|</span>' +
			'<span style="float:right;margin-right:14px;color:#888;font-size:14px;">' + this.kindLabel() + '</span>';
		$('sr-kbd').innerHTML = this.osk.html();
		var h = '';
		if (this.loading) { h = '<div class="empty" style="padding-left:10px">Carregando a lista\u2026</div>'; }
		else if (this.q.length < 2) { h = '<div class="empty" style="padding-left:10px">Digite ao menos 2 letras.</div>'; }
		else if (!this.results.length) { h = '<div class="empty" style="padding-left:10px">' + esc(this.msg || 'Nada encontrado.') + '</div>'; }
		else {
			var live = this.kind === 'live', v = live ? 5 : 7;
			h = '<div class="row-title">Resultados (' + this.results.length + ')</div><div class="row-cards">' +
				cardsHtml(this.results, this.start, v, this.col, S.zone === 'content' && this.zone === 'r') + '</div>';
		}
		$('sr-res').innerHTML = h;
	},
	schedule: function () {
		var me = this;
		if (this.timer) { clearTimeout(this.timer); }
		this.timer = setTimeout(function () { me.run(); }, 450);
	},
	run: function () {
		var me = this, q = this.q.toLowerCase(), kind = this.kind;
		this.results = []; this.col = 0; this.start = 0; this.msg = '';
		if (q.length < 2) { this.loading = false; this.draw(); return; }
		var go = function (list) {
			if (me.kind !== kind || me.q.toLowerCase() !== q) { return; }
			var out = [];
			for (var i = 0; i < list.length && out.length < 80; i++) {
				if (list[i].name.toLowerCase().indexOf(q) > -1 && !isAdultItem(kind, list[i])) { out.push(list[i]); }
			}
			me.results = out; me.loading = false; me.draw();
		};
		if (All[kind]) { go(All[kind]); return; }
		this.loading = true; this.draw();
		var load = function () {
			Api.items(kind, null, function (list) { All[kind] = list; go(list); },
				function (e) { me.loading = false; me.msg = e; me.draw(); });
		};
		if (Cats[kind]) { load(); }
		else { Api.cats(kind, function (c) { Cats[kind] = c; load(); }, function () { load(); }); }
	},
	onKey: function (t) {
		if (t === null) { return; }
		if (t === 'Canais') { this.kind = 'live'; }
		else if (t === 'Filmes') { this.kind = 'movie'; }
		else if (t === 'S\u00e9ries') { this.kind = 'series'; }
		else if (t === 'Espa\u00e7o') { this.q += ' '; }
		else if (t === 'Apagar') { this.q = this.q.substr(0, this.q.length - 1); }
		else if (t === 'Limpar') { this.q = ''; }
		else { this.q += t; }
		this.osk.on = this.kindLabel();
		this.schedule();
	},
	key: function (a) {
		if (S.zone === 'tabs') { tabsKey(a); return; }
		if (this.zone === 'k') {
			if (a === 'left' || a === 'right' || a === 'up' || a === 'down') {
				var moved = this.osk.move(a);
				if (!moved && a === 'up') { S.zone = 'tabs'; drawHeader(); }
				else if (!moved && a === 'down' && this.results.length) { this.zone = 'r'; }
			} else if (a === 'enter') { this.onKey(this.osk.press()); }
			else if (a === 'back') { S.zone = 'tabs'; drawHeader(); }
		} else {
			var it = this.results[this.col], v = this.kind === 'live' ? 5 : 7;
			if (a === 'left' && this.col > 0) { this.col--; }
			else if (a === 'right' && this.col < this.results.length - 1) { this.col++; }
			else if (a === 'up' || a === 'back') { this.zone = 'k'; }
			else if (a === 'enter' && it) { openItem(it); return; }
			else if (a === 'red' && it) { Favs.toggle(it); }
			if (this.col < this.start) { this.start = this.col; } else if (this.col >= this.start + v) { this.start = this.col - v + 1; }
		}
		this.draw();
	}
};

/* ---------- ajustes ---------- */
var Settings = {
	opt: 0,
	draw: function () {
		var rows = [
			['Formato dos canais ao vivo', Prefs.data.liveFmt === 'm3u8' ? 'HLS (m3u8)' : 'MPEG-TS (ts)'],
			['Conte\u00fado adulto', 'Bloqueado'],
			['Sair da conta', Api.user],
			['Sobre', 'Prisma ' + VERSION]
		];
		var h = '';
		for (var i = 0; i < rows.length; i++) {
			var sel = S.zone === 'content' && i === this.opt;
			h += '<div class="opt' + (sel ? ' sel' : '') + '">' + rows[i][0] + '<span class="v">' + esc(rows[i][1]) + '</span></div>';
		}
		$('st-list').innerHTML = h;
	},
	key: function (a) {
		if (S.zone === 'tabs') { tabsKey(a); return; }
		if (a === 'up') { if (this.opt > 0) { this.opt--; } else { S.zone = 'tabs'; drawHeader(); } }
		else if (a === 'down') { if (this.opt < 3) { this.opt++; } }
		else if (a === 'back') { S.zone = 'tabs'; drawHeader(); }
		else if (a === 'enter') {
			if (this.opt === 0) { Prefs.data.liveFmt = Prefs.data.liveFmt === 'm3u8' ? 'ts' : 'm3u8'; Prefs.save(); }
						else if (this.opt === 2) { Login.logout(); return; }
		}
		this.draw();
	}
};

/* ---------- login ---------- */
var Login = {
	f: 0, zone: 'f', osk: null, vals: ['http://', '', ''], busy: false, msg: '',
	enter: function () {
		if (!this.osk) { this.osk = new Osk(KB_LOGIN); }
		showScreen('login');
		this.draw();
	},
	draw: function () {
		var names = ['Servidor', 'Usu\u00e1rio', 'Senha'], h = '';
		for (var i = 0; i < 3; i++) {
			var v = i === 2 ? this.vals[i].replace(/./g, '\u2022') : this.vals[i];
			var cls = 'fld' + (this.f === i ? (this.zone === 'k' ? ' edit' : ' sel') : '');
			h += '<div class="' + cls + '"><span class="lb">' + names[i] + '</span>' + esc(v) +
				(this.f === i && this.zone === 'k' ? '<span style="color:#e50914">|</span>' : '') + '</div>';
		}
		h += '<div class="btn-login' + (this.f === 3 ? ' sel' : '') + '">' + (this.busy ? 'Conectando\u2026' : 'Entrar') + '</div>';
		$('lg-fields').innerHTML = h;
		$('lg-msg').innerHTML = esc(this.msg);
		this.osk.active = this.zone === 'k';
		$('lg-kbd').innerHTML = this.osk.html();
	},
	key: function (a) {
		if (this.busy) { return; }
		if (this.zone === 'f') {
			if (a === 'up' && this.f > 0) { this.f--; }
			else if (a === 'down' && this.f < 3) { this.f++; }
			else if (a === 'enter') { if (this.f < 3) { this.zone = 'k'; } else { this.submit(); return; } }
			else if (a === 'back') { exitApp(); }
		} else {
			if (a === 'left' || a === 'right' || a === 'up' || a === 'down') { this.osk.move(a); }
			else if (a === 'enter') {
				var t = this.osk.def[this.osk.r][this.osk.c];
				if (t === 'OK') { this.zone = 'f'; if (this.f < 3) { this.f++; } }
				else {
					var p = this.osk.press();
					if (p !== null) {
						if (p === 'Espa\u00e7o') { p = ' '; }
						if (p === 'Apagar') { this.vals[this.f] = this.vals[this.f].substr(0, this.vals[this.f].length - 1); }
						else { this.vals[this.f] += p; }
					}
				}
			} else if (a === 'back') { this.zone = 'f'; }
		}
		this.draw();
	},
	submit: function () {
		var me = this, s = this.vals[0].replace(/\s+/g, ''), u = this.vals[1].replace(/\s+/g, ''), p = this.vals[2];
		if (s.length < 8 || !u || !p) { this.msg = 'Preencha servidor, usu\u00e1rio e senha.'; this.draw(); return; }
		if (s.indexOf('http://') !== 0 && s.indexOf('https://') !== 0) { s = 'http://' + s; }
		while (s.charAt(s.length - 1) === '/') { s = s.substr(0, s.length - 1); }
		this.busy = true; this.msg = ''; this.draw();
		var c = { server: s, user: u, pass: p };
		Api.set(c);
		Api.login(function () {
			me.busy = false;
			Store.set('creds', c);
			Cats = {}; All = {};
			startApp();
		}, function (e) { me.busy = false; me.msg = e; me.draw(); });
	},
	logout: function () {
		Store.del('creds'); Store.set('favs', []); Store.set('recent', []);
		Favs.list = []; Recent.list = []; Cats = {}; All = {};
		this.vals = ['http://', '', '']; this.f = 0; this.zone = 'f'; this.msg = '';
		this.enter();
	}
};

/* ---------- detalhes de filme/serie ---------- */
var Detail = {
	it: null, info: null, eps: [], zone: 'btn', b: 0, e: 0, es: 0, loading: false, err: '',
	open: function (it) {
		var me = this;
		this.it = it; this.info = null; this.eps = []; this.zone = 'btn'; this.b = 0; this.e = 0; this.es = 0;
		this.loading = true; this.err = '';
		S.prev = S.screen === 'detail' ? S.prev : S.screen;
		showScreen('detail');
		this.draw();
		var done = function (info, eps) {
			if (me.it !== it) { return; }
			me.info = info || {}; me.eps = eps || []; me.loading = false; me.draw();
		};
		var fail = function (e) { if (me.it === it) { me.err = e; me.loading = false; me.info = {}; me.draw(); } };
		if (it.k === 'series') { Api.seriesInfo(it.id, done, fail); }
		else { Api.movieInfo(it.id, function (i) { done(i, []); }, fail); }
	},
	close: function () {
		this.it = null;
		showScreen(S.prev);
		if (S.prev === 'browse') { if (Browse.curKind() === 'home') { Browse.refreshHome(); } else { Browse.draw(); } }
		else if (S.prev === 'search') { Search.draw(); }
		drawHeader();
	},
	resumeRec: function () { return this.it ? Recent.find(this.it) : null; },
	draw: function () {
		var it = this.it, info = this.info || {}, rec = this.resumeRec();
		var meta = [];
		var year = String(info.releasedate || info.releaseDate || '').substr(0, 4);
		if (year) { meta.push(year); }
		if (info.genre) { meta.push(info.genre); }
		if (info.duration) { meta.push(info.duration); }
		if (info.rating && String(info.rating) !== '0') { meta.push('\u2605 ' + info.rating); }
		var h = '<div class="d-pic">' + (it.img ? '<img src="' + esc(it.img) + '" onerror="this.style.display=\'none\'">' : '') + '</div>';
		h += '<div class="d-title">' + esc(it.name) + '</div>';
		h += '<div class="d-meta">' + esc(meta.join('   \u00b7   ')) + '</div>';
		if (this.loading) { h += '<div class="d-load">Carregando\u2026</div>'; }
		else { h += '<div class="d-plot">' + esc(cut(info.plot || info.description || (this.err ? this.err : ''), 420)) + '</div>'; }
		var cast = info.cast || info.actors || '';
		if (cast) { h += '<div class="d-cast">Elenco: ' + esc(cut(cast, 150)) + '</div>'; }
		h += '<div class="d-btns">';
		h += '<div class="btn' + (this.zone === 'btn' && this.b === 0 ? ' sel' : '') + '">\u25b6  ' + (rec ? 'Continuar' : 'Assistir') + '</div>';
		h += '<div class="btn' + (this.zone === 'btn' && this.b === 1 ? ' sel' : '') + '">' + (Favs.has(it) ? '\u2713  Na minha lista' : '+  Minha lista') + '</div>';
		h += '</div>';
		if (it.k === 'series' && !this.loading) {
			h += '<div class="d-eps">';
			if (!this.eps.length) { h += '<div class="ep">Nenhum epis\u00f3dio encontrado.</div>'; }
			else {
				var lines = 6, i, last = -1, n = 0;
				for (i = this.es; i < this.eps.length && n < lines; i++) {
					var ep = this.eps[i];
					if (ep.season !== last && (i === this.es || ep.season !== this.eps[i - 1].season)) {
						h += '<div class="ep-h">Temporada ' + ep.season + '</div>'; n++; last = ep.season;
						if (n >= lines) { break; }
					}
					h += '<div class="ep' + (this.zone === 'eps' && i === this.e ? ' sel' : '') + '">E' + ep.num + '  \u00b7  ' + esc(cut(ep.title, 70)) + '</div>';
					n++;
				}
			}
			h += '</div>';
		}
		$('scr-detail').innerHTML = h;
	},
	fixEps: function () {
		if (this.e < this.es) { this.es = this.e; }
		else if (this.e > this.es + 4) { this.es = this.e - 4; }
	},
	playEpisode: function (idx, start) {
		var ep = this.eps[idx], it = this.it;
		if (!ep) { return; }
		Player.play({
			url: Api.episodeUrl(ep.id, ep.ext), title: it.name + ' \u00b7 ' + ep.title, item: it,
			start: start || 0, eps: this.eps, idx: idx
		});
	},
	key: function (a) {
		var it = this.it;
		if (a === 'back') { this.close(); return; }
		if (a === 'red') { Favs.toggle(it); this.draw(); return; }
		if (this.zone === 'btn') {
			if (a === 'left' && this.b > 0) { this.b--; }
			else if (a === 'right' && this.b < 1) { this.b++; }
			else if (a === 'down' && it.k === 'series' && this.eps.length) { this.zone = 'eps'; }
			else if (a === 'enter') {
				if (this.b === 1) { Favs.toggle(it); }
				else if (this.loading) { return; }
				else if (it.k === 'movie') {
					var rec = this.resumeRec();
					Player.play({ url: Api.movieUrl(it.id, it.ext), title: it.name, item: it, start: rec ? rec.pos : 0 });
					return;
				} else if (this.eps.length) {
					var r = this.resumeRec(), idx = 0, st = 0;
					if (r) {
						for (var i = 0; i < this.eps.length; i++) {
							if (Api.episodeUrl(this.eps[i].id, this.eps[i].ext) === r.url) { idx = i; st = r.pos; break; }
						}
					}
					this.playEpisode(idx, st);
					return;
				}
			}
		} else {
			if (a === 'up') { if (this.e > 0) { this.e--; this.fixEps(); } else { this.zone = 'btn'; } }
			else if (a === 'down' && this.e < this.eps.length - 1) { this.e++; this.fixEps(); }
			else if (a === 'enter') { this.playEpisode(this.e, 0); return; }
		}
		this.draw();
	}
};

function openItem(it) {
	if (it.k === 'live') {
		Player.play({ url: Api.liveUrl(it.id), title: it.name, item: null, live: true, start: 0 });
	} else { Detail.open(it); }
}

/* ---------- player ---------- */
var Player = {
	plugin: null, mode: '', cur: null, pos: 0, dur: 0, paused: false, osdTimer: null, lastSave: 0, back: 'browse',
	init: function () {
		var p = $('pluginPlayer');
		try { if (p && typeof p.Play !== 'undefined') { this.plugin = p; this.mode = 'infolink'; } } catch (e) {}
		if (!this.mode) { this.mode = 'html5'; }
		Log.add('Player: ' + this.mode);
	},
	play: function (o) {
		var me = this;
		this.cur = o; this.pos = 0; this.dur = 0; this.paused = false; this.lastSave = 0;
		this.back = S.screen === 'detail' ? 'detail' : S.screen;
		showScreen('player');
		$('pl-msg').innerHTML = 'Carregando\u2026';
		this.showOsd();
		try {
			if (this.mode === 'infolink') {
				var p = this.plugin;
				p.OnCurrentPlayTime = 'Player_onTime';
				p.OnStreamInfoReady = 'Player_onInfo';
				p.OnRenderingComplete = 'Player_onEnd';
				p.OnBufferingStart = 'Player_onBufStart';
				p.OnBufferingComplete = 'Player_onBufEnd';
				p.OnConnectionFailed = 'Player_onErr';
				p.OnStreamNotFound = 'Player_onErr';
				p.OnNetworkDisconnected = 'Player_onErr';
				p.OnRenderError = 'Player_onErr';
				p.OnAuthenticationFailed = 'Player_onErr';
				try { p.SetDisplayArea(0, 0, 960, 540); } catch (e1) {}
				var u = o.url;
				if (u.indexOf('.m3u8') > -1) { u += '|COMPONENT=HLS'; }
				if (o.start > 5000) { p.ResumePlay(u, Math.floor(o.start / 1000)); } else { p.Play(u); }
			} else {
				var v = $('html5');
				v.style.display = 'block';
				v.onplaying = function () { $('pl-msg').innerHTML = ''; };
				v.ontimeupdate = function () { me.pos = Math.floor(v.currentTime * 1000); me.dur = isNaN(v.duration) ? 0 : Math.floor(v.duration * 1000); me.tick(); };
				v.onended = function () { me.ended(); };
				v.onerror = function () { me.error('Nao foi possivel reproduzir'); };
				v.src = o.url;
				if (o.start > 5000) { try { v.currentTime = o.start / 1000; } catch (e2) {} }
				v.play();
			}
		} catch (e) { this.error('Erro ao iniciar: ' + e.message); }
	},
	tick: function () {
		var c = this.cur;
		if (c && c.item && this.dur > 0 && this.pos - this.lastSave > 10000) { this.save(); }
		if ($('osd').style.display === 'block') { this.drawOsd(); }
	},
	save: function () {
		var c = this.cur;
		if (c && c.item && this.dur > 0 && this.pos > 5000) {
			Recent.put(c.item, c.url, c.title, this.pos, this.dur);
			this.lastSave = this.pos;
		}
	},
	drawOsd: function () {
		var c = this.cur, h = '<div class="osd-title">' + esc(c ? c.title : '') + '</div>';
		if (c && c.live) { h += '<div class="osd-time">AO VIVO</div>'; }
		else {
			var pct = this.dur > 0 ? Math.min(100, Math.round(100 * this.pos / this.dur)) : 0;
			h += '<div class="osd-bar"><div style="width:' + pct + '%"></div></div>';
			h += '<div class="osd-time">' + fmtTime(this.pos) + ' / ' + fmtTime(this.dur) + (this.paused ? '     \u275a\u275a PAUSADO' : '') + '</div>';
		}
		$('osd').innerHTML = h;
	},
	showOsd: function () {
		var me = this;
		$('osd').style.display = 'block';
		this.drawOsd();
		if (this.osdTimer) { clearTimeout(this.osdTimer); }
		this.osdTimer = setTimeout(function () { $('osd').style.display = 'none'; }, 5000);
	},
	error: function (m) { $('pl-msg').innerHTML = esc(m) + '<br><span style="font-size:15px">Aperte RETURN para voltar</span>'; },
	ended: function () {
		var c = this.cur;
		if (c && c.item) { this.dur = this.dur || 1; this.pos = this.dur; Recent.put(c.item, c.url, c.title, this.dur, this.dur); }
		if (c && c.eps && c.idx + 1 < c.eps.length) {
			var nx = c.eps[c.idx + 1];
			this.cur = null;
			Player.stopMedia();
			Player.play({ url: Api.episodeUrl(nx.id, nx.ext), title: c.item.name + ' \u00b7 ' + nx.title, item: c.item, start: 0, eps: c.eps, idx: c.idx + 1 });
		} else { this.stop(false); }
	},
	stopMedia: function () {
		try {
			if (this.mode === 'infolink') { this.plugin.Stop(); }
			else { var v = $('html5'); v.pause(); v.removeAttribute('src'); v.style.display = 'none'; }
		} catch (e) {}
	},
	stop: function (silent) {
		if (S.screen !== 'player' && !this.cur) { return; }
		this.save();
		this.stopMedia();
		if (this.osdTimer) { clearTimeout(this.osdTimer); }
		$('osd').style.display = 'none';
		this.cur = null;
		if (silent) { return; }
		if (this.back === 'detail' && Detail.it) { showScreen('detail'); Detail.draw(); }
		else { showScreen(this.back === 'search' ? 'search' : 'browse'); if (S.screen === 'browse') { Browse.draw(); } else { Search.draw(); } drawHeader(); }
	},
	jump: function (sec) {
		var me = this;
		if (!this.cur || this.cur.live) { return; }
		try {
			if (this.mode === 'infolink') { if (sec > 0) { this.plugin.JumpForward(sec); } else { this.plugin.JumpBackward(-sec); } }
			else { var v = $('html5'); v.currentTime = Math.max(0, v.currentTime + sec); }
		} catch (e) {}
	},
	toggle: function () {
		try {
			if (this.mode === 'infolink') { if (this.paused) { this.plugin.Resume(); } else { this.plugin.Pause(); } }
			else { var v = $('html5'); if (this.paused) { v.play(); } else { v.pause(); } }
			this.paused = !this.paused;
		} catch (e) {}
	},
	key: function (a) {
		if (a === 'back' || a === 'stop') { this.stop(false); return; }
		if (a === 'enter' || a === 'play' || a === 'pause') { this.toggle(); }
		else if (a === 'left' || a === 'rw') { this.jump(-10); }
		else if (a === 'right' || a === 'ff') { this.jump(10); }
		this.showOsd();
	}
};

/* funcoes chamadas pelo player da TV (precisam ser globais) */
function Player_onTime(t) { Player.pos = parseInt(t, 10) || 0; Player.tick(); }
function Player_onInfo() {
	try { Player.dur = Player.plugin.GetDuration(); } catch (e) {}
	$('pl-msg').innerHTML = '';
}
function Player_onEnd() { Player.ended(); }
function Player_onBufStart() { $('pl-msg').innerHTML = 'Carregando\u2026'; }
function Player_onBufEnd() { $('pl-msg').innerHTML = ''; }
function Player_onErr(e) { Player.error('Nao foi possivel reproduzir (' + e + ')'); Log.add('Erro do player: ' + e); }

/* ---------- teclas ---------- */
var KEYMAP = {
	4: 'left', 37: 'left', 5: 'right', 39: 'right', 29460: 'up', 38: 'up', 29461: 'down', 40: 'down',
	29443: 'enter', 13: 'enter', 88: 'back', 8: 'back', 27: 'back', 10009: 'back', 45: 'exit',
	71: 'play', 415: 'play', 74: 'pause', 19: 'pause', 70: 'stop', 413: 'stop',
	72: 'ff', 417: 'ff', 69: 'rw', 412: 'rw',
	108: 'red', 403: 'red', 20: 'green', 404: 'green', 21: 'yellow', 405: 'yellow', 22: 'blue', 406: 'blue'
};
function loadKeyNames() {
	try {
		if (window.Common && Common.API && Common.API.TVKeyValue) {
			var t = new Common.API.TVKeyValue();
			var m = { KEY_LEFT: 'left', KEY_RIGHT: 'right', KEY_UP: 'up', KEY_DOWN: 'down', KEY_ENTER: 'enter',
				KEY_RETURN: 'back', KEY_EXIT: 'exit', KEY_PLAY: 'play', KEY_PAUSE: 'pause', KEY_STOP: 'stop',
				KEY_FF: 'ff', KEY_RW: 'rw', KEY_RED: 'red', KEY_GREEN: 'green', KEY_YELLOW: 'yellow', KEY_BLUE: 'blue' };
			for (var n in m) { if (m.hasOwnProperty(n) && t[n] !== undefined) { KEYMAP[t[n]] = m[n]; } }
		}
	} catch (e) {}
}

function dispatch(a) {
	if (a === 'blue') { Log.toggle(); return; }
	if (a === 'exit') { Player.stop(true); try { if (widgetAPI) { widgetAPI.sendExitEvent(); } } catch (e) {} return; }
	var s = S.screen;
	if (s === 'login') { Login.key(a); }
	else if (s === 'browse') { Browse.key(a); }
	else if (s === 'search') { Search.key(a); }
	else if (s === 'settings') { Settings.key(a); }
	else if (s === 'detail') { Detail.key(a); }
	else if (s === 'player') { Player.key(a); }
}

function onKeyDown(e) {
	e = e || window.event;
	var a = KEYMAP[e.keyCode];
	if (!a) { Log.add('tecla ' + e.keyCode); return true; }
	try { if (widgetAPI) { widgetAPI.blockNavigation(e); } } catch (x) {}
	if (e.preventDefault) { e.preventDefault(); }
	try { dispatch(a); } catch (err) { Log.add('ERRO: ' + err.message); }
	return false;
}

/* ---------- inicio ---------- */
function startApp() {
	S.tab = 0; S.zone = 'tabs';
	showScreen('browse');
	applyTab();
}

var App = {
	init: function () {
		try { widgetAPI = new Common.API.Widget(); } catch (e) { widgetAPI = null; }
		loadKeyNames();
		Prefs.load(); Favs.load(); Recent.load(); Player.init();
		document.onkeydown = onKeyDown;
		try { $('anchor').focus(); } catch (e2) {}
		try { if (widgetAPI) { widgetAPI.sendReadyEvent(); } } catch (e3) {}
		setTimeout(function () {
			$('splash').style.display = 'none';
			var c = Store.get('creds', null);
			if (c && c.server) { Api.set(c); startApp(); }
			else { Login.enter(); }
		}, 1400);
	}
};
